﻿#class setup(object):
#    """description of class"""

from distutils.core import setup

setup(
     name = "PythonTestModule",
     version = "1.1.0",
     py_modules = ["printData"],
     description = "Test Module"
     )

